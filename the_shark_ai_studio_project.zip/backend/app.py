import os, json, tempfile, shutil, subprocess, re
from pathlib import Path
from typing import Optional
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from faster_whisper import WhisperModel

app = FastAPI(title="The Shark AI Studio API", version="0.1.0")
# MVP convenience setting. For production, replace "*" with your exact GitHub Pages origin.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)
_model = None
MAX_UPLOAD_MB = int(os.getenv("MAX_UPLOAD_MB", "250"))

def get_model():
    global _model
    if _model is None:
        # tiny keeps RAM/model download lower; accuracy is lower than base/small.
        _model = WhisperModel(os.getenv("WHISPER_MODEL", "tiny"), device="cpu", compute_type="int8")
    return _model

def safe_ext(filename: Optional[str]) -> str:
    ext = Path(filename or "upload.mp4").suffix.lower()
    if ext not in {".mp4", ".mov", ".mkv", ".webm", ".m4v", ".avi"}:
        return ".mp4"
    return ext

def save_upload(upload: UploadFile, folder: str) -> Path:
    path = Path(folder) / ("input" + safe_ext(upload.filename))
    size = 0
    with path.open("wb") as out:
        while True:
            chunk = upload.file.read(1024 * 1024)
            if not chunk:
                break
            size += len(chunk)
            if size > MAX_UPLOAD_MB * 1024 * 1024:
                path.unlink(missing_ok=True)
                raise HTTPException(413, f"File terlalu besar. Batas konfigurasi {MAX_UPLOAD_MB} MB.")
            out.write(chunk)
    if size == 0:
        raise HTTPException(400, "File kosong.")
    return path

@app.get("/")
def root():
    return {"name": "The Shark AI Studio API", "docs": "/docs", "health": "/health"}

@app.get("/health")
def health():
    return {"ok": True, "service": "The Shark AI Studio API", "model": os.getenv("WHISPER_MODEL", "tiny")}

@app.post("/transcribe")
def transcribe(file: UploadFile = File(...), language: str = Form("id")):
    with tempfile.TemporaryDirectory(prefix="shark_asr_") as td:
        input_path = save_upload(file, td)
        try:
            model = get_model()
            lang = None if language == "auto" else language
            segments, info = model.transcribe(
                str(input_path), language=lang, beam_size=1, vad_filter=True,
                condition_on_previous_text=False
            )
            result = []
            for s in segments:
                text = (s.text or "").strip()
                if text:
                    result.append({"start": round(float(s.start), 3), "end": round(float(s.end), 3), "text": text})
            return {"language": info.language, "language_probability": round(float(info.language_probability), 3), "segments": result}
        except HTTPException:
            raise
        except Exception as e:
            raise HTTPException(500, f"Transkripsi gagal: {str(e)[:300]}")

def color_hex(value: str, default: str) -> str:
    v = (value or default).strip()
    if not re.fullmatch(r"#[0-9a-fA-F]{6}", v):
        return default
    return v

def ass_color(hex_color: str, alpha="00") -> str:
    h = hex_color.lstrip("#")
    r, g, b = h[0:2], h[2:4], h[4:6]
    return f"&H{alpha}{b}{g}{r}"

def ass_time(seconds: float) -> str:
    cs = max(0, round(float(seconds) * 100))
    h, rem = divmod(cs, 360000)
    m, rem = divmod(rem, 6000)
    s, cent = divmod(rem, 100)
    return f"{h}:{m:02d}:{s:02d}.{cent:02d}"

def ass_escape(text: str) -> str:
    # ASS override sequences are escaped by removing braces and normalizing newlines.
    return str(text).replace("{", "(").replace("}", ")").replace("\n", r"\N").replace("\r", "")

@app.post("/render")
def render(
    file: UploadFile = File(...),
    subtitles: str = Form(...),
    ratio: str = Form("9:16"),
    font_size: int = Form(32),
    font_color: str = Form("#ffffff"),
    outline_color: str = Form("#000000"),
    bg_color: str = Form("#000000"),
    position: str = Form("bottom"),
    resolution: int = Form(720),
    fps: int = Form(30),
    crf: int = Form(23),
    audio: str = Form("keep"),
):
    try:
        subs = json.loads(subtitles)
        if not isinstance(subs, list):
            raise ValueError("Subtitle harus berupa daftar.")
    except Exception:
        raise HTTPException(400, "Format subtitle JSON tidak valid.")
    if ratio not in {"9:16", "16:9", "1:1", "4:5"}:
        raise HTTPException(400, "Rasio tidak didukung.")
    if resolution not in {480, 720, 1080} or fps not in {24, 30, 60} or crf not in {18, 23, 28}:
        raise HTTPException(400, "Pengaturan ekspor tidak valid.")
    font_size = max(12, min(int(font_size), 72))
    font_color = color_hex(font_color, "#ffffff")
    outline_color = color_hex(outline_color, "#000000")
    bg_color = color_hex(bg_color, "#000000")
    position_map = {"bottom": 2, "middle": 5, "top": 8}
    alignment = position_map.get(position, 2)
    try:
        with tempfile.TemporaryDirectory(prefix="shark_render_") as td:
            src = save_upload(file, td)
            ass_path = Path(td) / "captions.ass"
            out_path = Path(td) / "output.mp4"
            header = f"""[Script Info]
ScriptType: v4.00+
PlayResX: 1080
PlayResY: 1920
WrapStyle: 2
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,DejaVu Sans,{font_size},{ass_color(font_color)},{ass_color(font_color)},{ass_color(outline_color)},{ass_color(bg_color,"80")},-1,0,0,0,100,100,0,0,3,3,1,{alignment},60,60,90,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
            events = []
            for item in subs[:3000]:
                try:
                    start = max(0.0, float(item.get("start", 0)))
                    end = max(start + 0.05, float(item.get("end", start + 1)))
                    text = ass_escape(item.get("text", ""))
                    if text.strip():
                        events.append(f"Dialogue: 0,{ass_time(start)},{ass_time(end)},Default,,0,0,0,,{text}")
                except (TypeError, ValueError):
                    continue
            ass_path.write_text(header + "\n".join(events) + "\n", encoding="utf-8")
            # Scale/crop to selected canvas. FFmpeg output is capped to even dimensions.
            if ratio == "9:16":
                w, h = (round(resolution * 9 / 16), resolution) if resolution >= 720 else (270, 480)
                # 720p portrait convention means 720x1280, not 405x720.
                w, h = {480:(270,480),720:(405,720),1080:(608,1080)}[resolution]
            elif ratio == "16:9":
                w, h = {480:(854,480),720:(1280,720),1080:(1920,1080)}[resolution]
            elif ratio == "1:1":
                w, h = {480:(480,480),720:(720,720),1080:(1080,1080)}[resolution]
            else:
                w, h = {480:(384,480),720:(576,720),1080:(864,1080)}[resolution]
            vf = f"scale={w}:{h}:force_original_aspect_ratio=decrease,pad={w}:{h}:(ow-iw)/2:(oh-ih)/2,setsar=1,fps={fps},subtitles={ass_path.as_posix()}"
            cmd = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", str(src), "-vf", vf, "-c:v", "libx264", "-preset", "veryfast", "-crf", str(crf), "-pix_fmt", "yuv420p"]
            if audio == "mute":
                cmd += ["-an"]
            else:
                cmd += ["-c:a", "aac", "-b:a", "128k", "-shortest"]
            cmd += ["-movflags", "+faststart", str(out_path)]
            p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=900)
            if p.returncode != 0 or not out_path.exists():
                raise HTTPException(500, "FFmpeg gagal: " + (p.stderr or "proses tidak selesai")[-1200:])
            # FileResponse streams file; temp directory cleanup after response may be platform-dependent.
            # Use a background task to remove temporary folder only after response has been sent.
            from starlette.background import BackgroundTask
            tmpdir = td
            # Detach temp dir cleanup from context manager by copying output to persistent temp path.
            final_dir = tempfile.mkdtemp(prefix="shark_download_")
            final_path = Path(final_dir) / "the-shark-ai-studio.mp4"
            shutil.copyfile(out_path, final_path)
            return FileResponse(str(final_path), media_type="video/mp4", filename="the-shark-ai-studio.mp4",
                                background=BackgroundTask(shutil.rmtree, final_dir, ignore_errors=True))
    except HTTPException:
        raise
    except subprocess.TimeoutExpired:
        raise HTTPException(504, "Ekspor melewati batas waktu server. Coba video yang lebih pendek atau resolusi lebih rendah.")
    except Exception as e:
        raise HTTPException(500, f"Ekspor gagal: {str(e)[:400]}")
