---
title: The Shark AI Studio Backend
emoji: 🦈
colorFrom: blue
colorTo: indigo
sdk: docker
app_port: 7860
---

# The Shark AI Studio Backend

FastAPI backend for speech transcription with faster-whisper and MP4 subtitle rendering with FFmpeg.

**Hosting note:** Check current account eligibility and billing before creating a Docker Space. Docker compute may require a subscription; do not assume it is available free on every account. If using another Docker/Python host, expose port 7860 or adapt the start command.

Free/low-cost CPU hosting may be slow, sleep when idle, or fail on large uploads. Test with a short clip first.
