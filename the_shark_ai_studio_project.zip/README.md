# The Shark AI Studio — MVP

Editor video web ringan dengan Auto Subtitle AI, ditujukan untuk Shorts, Reels, dan TikTok.

## Fitur pada versi ini
- Unggah video lokal dan pratinjau di browser.
- Pilih rasio kanvas 9:16, 16:9, 1:1, atau 4:5.
- Atur gaya subtitle (ukuran, warna, warna latar, posisi).
- Kirim video ke backend untuk transkripsi otomatis dengan Whisper.
- Edit teks dan timestamp subtitle hasil transkripsi.
- Ekspor MP4 dengan subtitle menyatu (burned-in) melalui FFmpeg di backend.
- Unduh file SRT.

## Batasan jujur
Ini MVP yang berfungsi untuk alur utama, bukan pengganti penuh CapCut. Belum ada multi-track timeline, keyframe, efek premium, transisi kompleks, cloud project, atau akun pengguna.
- Hosting frontend GitHub Pages gratis, tetapi hanya menyajikan file statis.
- Backend AI dan FFmpeg berjalan terpisah. Hugging Face Spaces CPU gratis bisa memiliki antrean, batas RAM/CPU, tidur saat tidak aktif, dan batas ukuran/waktu. Video panjang/1080p bisa gagal atau lambat.
- Model Whisper `tiny` dipakai sebagai default agar lebih ringan; akurasi Bahasa Indonesia mungkin lebih rendah daripada model besar.
- Tidak ada jaminan semua fitur/komputasi gratis tanpa batas.
- Video dikirim ke backend saat transkripsi/ekspor. Jangan unggah video pribadi/sensitif. File sementara akan dihapus setelah permintaan selesai, tetapi hosting pihak ketiga tetap memiliki kebijakan/log sendiri.
- Jangan menaruh API key/secret di frontend.

## Struktur
- `frontend/index.html` — antarmuka editor.
- `backend/app.py` — API FastAPI, Whisper, dan FFmpeg.
- `backend/requirements.txt` — dependensi Python.
- `backend/Dockerfile` — untuk deploy Docker Space.
- `backend/README.md` — petunjuk deploy backend.

## Jalankan backend secara lokal
Perlu Python 3.10+ dan FFmpeg terpasang di sistem.
```bash
cd backend
pip install -r requirements.txt
uvicorn app:app --host 0.0.0.0 --port 7860
```
Buka `http://localhost:7860/health`.

## Jalankan frontend lokal
Buka `frontend/index.html` di browser, lalu isi URL API dengan `http://localhost:7860`.
Jika browser membatasi akses `file://`, jalankan server statis:
```bash
python -m http.server 8080 --directory frontend
```
Lalu buka `http://localhost:8080`.

## Deploy online
1. Buat repo GitHub, unggah isi folder `frontend` ke repo frontend (atau gunakan folder root sesuai langkah README).
2. Di GitHub: **Settings → Pages → Deploy from a branch → main → / (root)** jika `index.html` berada di root.
3. Untuk percobaan, Render memiliki web service gratis, tetapi service tidur setelah 15 menit tanpa trafik, filesystem bersifat sementara, dan sumber daya terbatas. Model Whisper/FFmpeg dapat gagal karena RAM/CPU. Baca batas resmi sebelum deploy.
4. Unggah proyek ke GitHub. Di Render pilih **New → Web Service**, hubungkan repo, pilih **Docker** jika ditawarkan, pilih instance **Free**, lalu deploy folder backend sebagai repo terpisah atau root repo backend. Jika Render meminta Root Directory, isi `backend`.
5. Tunggu build selesai dan buka URL backend. Cek `/health`.
6. Di situs GitHub Pages, masukkan URL backend sebagai API URL.
7. Uji video pendek 5–15 detik terlebih dahulu.

Alternatif Hugging Face Docker Space juga perlu dicek kelayakan/paket akun terkini; jangan berasumsi compute Docker gratis untuk semua akun.

**Penting:** Jika belum memiliki layanan backend gratis yang memenuhi syarat, antarmuka tetap bisa diterbitkan, tetapi tombol AI dan ekspor belum bekerja sampai URL backend aktif. Jangan mengunggah file pribadi ke server publik.

## API
- `GET /health` — status backend.
- `POST /transcribe` — multipart `file`, opsional `language` (contoh `id`). Mengembalikan segmen dengan `start`, `end`, `text`.
- `POST /render` — multipart `file`, `subtitles` (JSON array), `ratio`, `font_size`, `font_color`, `outline_color`, `bg_color`, `position`; mengembalikan MP4.
